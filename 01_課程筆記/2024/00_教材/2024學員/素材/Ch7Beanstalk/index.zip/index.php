<body>
 <?php
 echo"<h1>Hello From Your Web Server!</h1>";
 ?>
</body>